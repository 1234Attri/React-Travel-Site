import './App.css'
import MainContent from './MainContent'

export default function App(){
  return (
    <div className='main-container'>
      <MainContent />
    </div>
  )
}